<?php $__env->startSection('content'); ?>
          <div class="d-flex justify-content-end mb-2">
                  <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success">Add Category</a>
          </div>
          <div class="card card-default">
            <div class="card-header">
                  Category
            </div>
            <div class="card-body">
                  <?php if($categories->count()>0): ?>
                  <table class="table">
                        <thead>
                            <th>Name</th>
                            <th>Post Counts</th>
                            <th></th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td><?php echo e($category->name); ?></td>
                                    <td><?php echo e($category->posts->count()); ?></td>
                                    <td>
                                      <a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-info btn-sm">Edit</a>
                                    </td>
                                    <td>
                                        <form class="delete_form" action="<?php echo e(route('categories.destroy',$category->id)); ?>" method="post">
                                              <?php echo csrf_field(); ?>
                                              <input type="hidden" name="_method" value="DELETE">
                                              <input type="submit" name="" value="Delete" class="btn btn-danger btn-sm">
                                        </form>
                                    </td>
                                  </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                  </table>
                  <?php else: ?>
                        <h3 class="text text-center">No Category</h3>
                  <?php endif; ?>
            </div>
          </div>
          <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
          <script type="text/javascript">
                  $(document).ready(function(){
                        $('.delete_form').on('submit',function(){
                              if(confirm("คุณต้องการลบข้อมูลหรือไม่")){
                                    return true;
                              }else{
                                    return false;
                              }

                        });
                  });
          </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmstutorial\resources\views/categories/index.blade.php ENDPATH**/ ?>