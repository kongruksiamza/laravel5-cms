<?php $__env->startSection('content'); ?>
          <div class="card card-default">
                  <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                              <ul class="list-group">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <li class="list-group-item"><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                        </div>
                  <?php endif; ?>
                  <div class="card-header">
                        <?php echo e(isset($post)?'Edit Post':'Create Post'); ?>

                  </div>
                  <div class="card-body">
                          <form action="<?php echo e(isset($post)?route('posts.update',$post->id):route('posts.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($post)): ?>
                                      <?php echo method_field('PUT'); ?>
                                <?php endif; ?>
                                <div class="form-group">
                                      <label for="title">Title</label>
                                      <input type="text" name="title" value="<?php echo e(isset($post)?$post->title:''); ?>" class="form-control">
                                </div>
                                <div class="form-group">
                                      <label for="title">Description</label>
                                      <textarea name="description" rows="4" cols="4" class="form-control"><?php echo e(isset($post)?$post->description:''); ?></textarea>
                                </div>
                                <div class="form-group">
                                      <label for="title">Content</label>
                                      <input id="x" type="hidden" name="content" value="<?php echo e(isset($post)?$post->content:''); ?>">
                                      <trix-editor input="x"></trix-editor>
                                </div>
                                <div class="form-group">
                                      <label for="title">Image</label>
                                      <input type="file" name="image" value="" class="form-control">
                                </div>
                                <div class="form-group">
                                      <label for="title">Category</label>
                                      <select class="form-control" name="category">
                                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <option value="<?php echo e($category->id); ?>"
                                                        <?php if(isset($post)): ?>
                                                            <?php if($category->id == $post->category_id): ?>
                                                                selected
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        ><?php echo e($category->name); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                </div>
                                <?php if($tags->count()>0): ?>
                                <div class="form-group">
                                      <label for="title">Tags</label>
                                      <select class="form-control" name="tags[]" id="select-tags" multiple>
                                              <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <option value="<?php echo e($tag->id); ?>"
                                                        <?php if(isset($post)): ?>
                                                            <?php if($post->hasTag($tag->id)): ?>
                                                                selected
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        ><?php echo e($tag->name); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                </div>
                                <?php endif; ?>
                                <div class="form-group">
                                      <input type="submit" name="" value="<?php echo e(isset($post)?'Update Post':'Create Post'); ?>" class="btn btn-success">
                                </div>
                          </form>
                  </div>
          </div>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.1.1/trix.js" charset="utf-8"></script>
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.1.1/trix.css">

          <script type="text/javascript">
                $(document).ready(function(){
                        $('#select-tags').select2();
                });
          </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cmstutorial\resources\views/posts/create.blade.php ENDPATH**/ ?>