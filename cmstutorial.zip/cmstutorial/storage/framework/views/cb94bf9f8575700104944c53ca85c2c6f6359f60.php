<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <?php echo $__env->yieldContent('title'); ?>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/page.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('img/apple-touch-icon.png')); ?>">
    <link rel="icon" href="<?php echo e(asset('img/favicon.png')); ?>">
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-light navbar-stick-dark" data-navbar="sticky">
      <div class="container">

        <div class="navbar-left">
          <button class="navbar-toggler" type="button">&#9776;</button>
          <a class="navbar-brand" href="<?php echo e(route('welcome')); ?>">
            <img class="logo-dark" src="<?php echo e(asset('img/logo-dark.png')); ?>" alt="logo">
            <img class="logo-light" src="<?php echo e(asset('img/logo-light.png')); ?>" alt="logo">
          </a>
        </div>
        <a class="btn btn-xs btn-round btn-success" href="<?php echo e(route('home')); ?>">Login</a>
      </div>
    </nav>

    <?php echo $__env->yieldContent('header'); ?>

    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('js/page.js')); ?>"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>

  </body>
</html>
<?php /**PATH C:\xampp\htdocs\cmstutorial\resources\views/layouts/blog.blade.php ENDPATH**/ ?>