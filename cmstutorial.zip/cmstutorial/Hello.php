h1='H'
e='e'
l1='l'
l2='l'
o1='o'
space=' '
p='P'
y='y'
t='t'
h2='h'
o2='o'
n='n'
symbol='!'
a=1
try:
    if a==1:
        print(h1+e+l1+l2+o1+space+p+y+t+h2+o2+n+symbol)
    else:
        print("No Message")
except:
    print ("Error")

//end method
